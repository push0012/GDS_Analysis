

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
      <div class="row " >
            <div class="col-md-12 " align="right">
             
              <a href="<?php echo e(url('/institutes/create')); ?>" class="btn btn-primary">
              
                <span class="material-icons left">
                add_circle
                </span>
                Add New
                </a>
              
            </div>
        </div>
      <div class="row ">
      <div class="col-md-12">
        <div class="card card-plain">
          <div class="card-header card-header-primary">
            <h4 class="card-title mt-0">Institute List</h4>
            <p class="card-category"> Here are the institutes those present student attended</p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover stripe" id="myTable">
                <thead class="">
                  <th>
                    ID
                  </th>
                  <th>
                    Institute Name
                  </th>
                  <th>
                    Institute Type
                  </th>
                  <th>
                    Institute Category
                  </th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>    
                      <th><?php echo e($data->ins_id); ?></th>
                      <th><?php echo e($data->ins_name); ?></th>
                      <th><?php echo e($data->ins_type); ?></th>
                      <th><?php echo e($data->ins_category); ?></th>          
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <!-- <tr>
                    <td>
                      1
                    </td>
                    <td>
                      Dakota Rice
                    </td>
                    <td>
                      Niger
                    </td>
                    <td>
                      Oud-Turnhout
                    </td>
                  </tr>
-->
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'institutes', 'titlePage' => __('Institute List')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/pages/institutes/institute_list.blade.php ENDPATH**/ ?>