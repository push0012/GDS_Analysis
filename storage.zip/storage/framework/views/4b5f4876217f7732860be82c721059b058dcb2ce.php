

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
      <div class="row " >
            <div class="col-md-12 " align="right">
             
              <a href="<?php echo e(url('/register/diploma/create')); ?>" class="btn btn-primary">
              
                <span class="material-icons left">
                add_circle
                </span>
                Add New
                </a>
              
            </div>
        </div>
      <div class="row ">
      <div class="col-md-12">
        <div class="card card-plain">
          <div class="card-header card-header-primary">
            <h4 class="card-title mt-0">Diploma Holding Student List</h4>
            <p class="card-category"> </p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover stripe" id="myTabledeg">
                <thead class="">
                  <th>
                    Reg No
                  </th>
                  <th>
                    Reg Date
                  </th>
                  <th>
                    Name
                  </th>
                  <th>
                    NIC
                  </th>
                  <th>
                    Division
                  </th>
                  <th>
                    Telephone
                  </th>
                  <th>
                    View
                  </th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>    
                      <th><?php echo e($data->dip_reg_no); ?></th>
                      <th><?php echo e($data->dip_reg_date); ?></th>
                      <th><?php echo e($data->stu_name); ?></th>        
                      <th><?php echo e($data->nic); ?></th>
                      <th><?php echo e($data->dv_name); ?></th>
                      <th><?php echo e($data->telephone); ?></th>  
                      <th><a href="<?php echo e(url('/register/diploma/view/'. $data->stu_id)); ?>"><span class="material-icons">visibility</span></a></th>     
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'diploma_list', 'titlePage' => __('Diploma Holder')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/pages/diploma/list.blade.php ENDPATH**/ ?>