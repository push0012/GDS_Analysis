<footer class="footer">
  <div class="container-fluid">
  <div class="copyright float-right">
     
      Copyright &copy;
      <a href="https://planning.sg.gov.lk" target="_blank">DCS (Planning) Office, Sabaragamuwa </a>
      <script>
        document.write(new Date().getFullYear())
      </script>
      
      <br>
      Design & Develop by Pushpamal Gunasena (IT Assistant) 
    </div>
  </div>
</footer><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>