

<?php $__env->startSection('content'); ?>
<style>
  .col-form-label{
    font-weight: bold;
    background-color: black !important;
    color: white !important;
  }
  hr{
    margin: 5px !important;
    border-top: 2px solid black !important;
  }
  .middle-button{
    padding: 5px;
    margin-right:10px;
    margin-top:10px;
    border-style: solid;
    border-radius:5px;
    cursor:pointer;
  }
</style>
  <div class="content">
    <div class="container-fluid">
      <div class="row " >
           <!-- <div class="col-md-12 " align="right">
             
              <a href="<?php echo e(url('/institutes')); ?>" class="btn btn-primary">
              
                <span class="material-icons left">
                list
                </span>
                Show Institute List
                </a>

            </div>-->
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(url('register/graduate/update/'.$student->stu_id)); ?>" autocomplete="off" class="form-horizontal">
          <!--action="<?php echo e(url('institutes')); ?>"-->
          <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary" style="padding-top:5px !important; padding-bottom:5px !important;">
                <h4 class="card-title"><?php echo e(__('Edit Graduate Student Details')); ?> </h4>
                
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label text-dark bg-info"><?php echo e(__('Register No')); ?></label>
                  <div class="col-sm-4">
                    <div class="form-group<?php echo e($errors->has('deg_reg_no') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('deg_reg_no') ? ' is-invalid' : ''); ?>" name="deg_reg_no" id="deg_reg_no" type="text" placeholder="" value="<?php echo e($student->deg_reg_no); ?>" required="true" aria-required="true" />
                      <?php if($errors->has('deg_reg_no')): ?>
                        <span id="ins_name-error" class="error text-danger" for="deg_reg_no"><?php echo e($errors->first('deg_reg_no')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <label class="col-sm-2 col-form-label text-dark bg-info"><?php echo e(__('Register Date')); ?></label>
                  <div class="col-sm-4">
                    <div class="form-group<?php echo e($errors->has('deg_reg_date') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('deg_reg_date') ? ' is-invalid' : ''); ?>" name="deg_reg_date" id="deg_reg_date" type="date" placeholder="" value="<?php echo e($student->deg_reg_date); ?>" required="true" aria-required="true" />
                      <?php if($errors->has('deg_reg_date')): ?>
                        <span id="deg_reg_date-error" class="error text-danger" for="deg_reg_date"><?php echo e($errors->first('deg_reg_date')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  
                </div>
                <hr>
                <div class="row">
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Title')); ?></label>
                  <div class="col-sm-1">
                    <div class="form-group<?php echo e($errors->has('stu_title') ? ' has-danger' : ''); ?>">
                      <select class="form-control" name="stu_title" id="stu_title">
                        <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                        
                        <option value="Rev." <?php echo e($student->stu_title == 'Rev.' ? 'selected' : ''); ?> >Rev.</option>

                        <option <?php echo e($student->stu_title == 'Mr.' ? 'selected' : ''); ?> value="Mr.">Mr.</option>
                        <option <?php echo e($student->stu_title == 'Mrs.' ? 'selected' : ''); ?> value="Mrs.">Mrs.</option>
                        <option <?php echo e($student->stu_title == 'Miss.' ? 'selected' : ''); ?> value="Miss">Miss.</option>
                      </select>
                      <?php if($errors->has('stu_title')): ?>
                        <span id="stu_title-error" class="error text-danger" for="stu_title"><?php echo e($errors->first('ins_type')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Name')); ?></label>
                  <div class="col-sm-6">
                    <div class="form-group<?php echo e($errors->has('stu_name') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('stu_name') ? ' is-invalid' : ''); ?>" name="stu_name" id="stu_name" type="text" placeholder="" value="<?php echo e($student->stu_name); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('stu_name')): ?>
                        <span id="stu_name-error" class="error text-danger" for="stu_name"><?php echo e($errors->first('stu_name')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Date of Birth')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('dob') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('dob') ? ' is-invalid' : ''); ?>" name="dob" id="dob" type="date" placeholder="" value="<?php echo e($student->dob); ?>" required="true" aria-required="true"/>
                            <?php if($errors->has('dob')): ?>
                                <span id="dob-error" class="error text-danger" for="dob"><?php echo e($errors->first('dob')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>  
                </div>
                <div class="row">
                 <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Gender')); ?></label>
                  <div class="col-sm-1">
                    <div class="form-group<?php echo e($errors->has('sex') ? ' has-danger' : ''); ?>">
                      <select class="form-control" name="sex" id="sex">
                        <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                        <option value="Male" <?php echo e($student->sex == 'Male' ? 'selected' : ''); ?> >Male</option>
                        <option value="Female" <?php echo e($student->sex == 'Female' ? 'selected' : ''); ?> >Female</option>
                      </select>
                      <?php if($errors->has('sex')): ?>
                        <span id="sex-error" class="error text-danger" for="sex"><?php echo e($errors->first('sex')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Address')); ?></label>
                    <div class="col-sm-6">
                        <div class="form-group<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" id="address" type="text" placeholder="" value="<?php echo e($student->address); ?>" required="true" aria-required="true"/>
                            <?php if($errors->has('address')): ?>
                                <span id="address-error" class="error text-danger" for="address"><?php echo e($errors->first('address')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>  
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('NIC')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('nic') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('nic') ? ' is-invalid' : ''); ?>" name="nic" id="nic" type="text" placeholder="" value="<?php echo e($student->nic); ?>" required="true" aria-required="true"/>
                            <?php if($errors->has('nic')): ?>
                                <span id="nic-error" class="error text-danger" for="nic"><?php echo e($errors->first('nic')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
                

                <div class="row">
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('District')); ?></label>
                    <div class="col-sm-1">
                    <div class="form-group<?php echo e($errors->has('ds_id') ? ' has-danger' : ''); ?>">
                      <select class="form-control" name="ds_id" id="ds_id">
                        <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                        <option value="1" <?php echo e($student->ds_name == 'Kegalle' ? 'selected' : ''); ?> >Kegalle</option>
                        <option value="2" <?php echo e($student->ds_name == 'Rathnapura' ? 'selected' : ''); ?> >Ratnapura</option>
                      </select>
                      <?php if($errors->has('ds_id')): ?>
                        <span id="ds_id-error" class="error text-danger" for="ds_id"><?php echo e($errors->first('ds_id')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('DS Area')); ?></label>
                  <div class="col-sm-1">
                    <div class="form-group<?php echo e($errors->has('dv_id') ? ' has-danger' : ''); ?>">
                      <select class="form-control" name="dv_id" id="dv_id">
                        <option value="0" selected="selected" disabled="disabled">Pick One...</option>
                        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($data->dv_id); ?>" <?php if($data->dv_id==$student->dv_id): ?> selected='selected' <?php endif; ?> ><?php echo e($data->dv_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php if($errors->has('dv_id')): ?>
                        <span id="dv_id-error" class="error text-danger" for="dv_id"><?php echo e($errors->first('dv_id')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('TP No')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('telephone') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('telephone') ? ' is-invalid' : ''); ?>" name="telephone" id="telephone" type="text" placeholder="" value="<?php echo e($student->telephone); ?>" required="true" aria-required="true"/>
                            <?php if($errors->has('telephone')): ?>
                                <span id="telephone-error" class="error text-danger" for="telephone"><?php echo e($errors->first('telephone')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Email Address')); ?></label>
                    <div class="col-sm-4">
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="email" type="email" placeholder="" value="<?php echo e($student->email); ?>" required="true" aria-required="true"/>
                            <?php if($errors->has('email')): ?>
                                <span id="email-error" class="error text-danger" for="email"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
                <hr>
                <div class="row">
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Institute')); ?></label>
                  <div class="col-sm-4">
                    <div class="form-group<?php echo e($errors->has('ins_id') ? ' has-danger' : ''); ?>">
                      <select class="form-control" name="ins_id" id="ins_id">
                        <option value="0" selected="selected" disabled="disabled">Pick One...</option>
                        <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($data->ins_id); ?>" <?php if($data->ins_id==$student->ins_id): ?> selected='selected' <?php endif; ?> ><?php echo e($data->ins_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      
                      <?php if($errors->has('ins_id')): ?>
                        <span id="ins_id-error" class="error text-danger" for="ins_id"><?php echo e($errors->first('ins_id')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  
                  <div class="col-sm-2" style="margin-top:10px;">
                  <a href="<?php echo e(url('institutes/create')); ?>" target="_blank" class="middle-button">
                      <span class="material-icons left">add</span>
                    </a>
                  
                    <a type="button" onclick="load_institute();" class="middle-button">
                      <span class="material-icons left">autorenew</span>
                    </a>
                  </div>
                  <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Degree')); ?></label>
                  <div class="col-sm-4">
                    <div class="form-group<?php echo e($errors->has('deg_title') ? ' has-danger' : ''); ?>">
                      <input class="form-control" list="deg_title" name="deg_title" value="<?php echo e($student->deg_title); ?>">
                      <datalist id="deg_title">
                        <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($data->deg_title); ?>" ></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </datalist>
                      <?php if($errors->has('deg_title')): ?>
                        <span id="deg_title-error" class="error text-danger" for="deg_title"><?php echo e($errors->first('deg_title')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>

                <div class="row">
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Degree Stream')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('str_id') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="str_id" id="str_id">
                            <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                            <?php $__currentLoopData = $streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($data->str_id); ?>" <?php if($data->str_id==$student->str_id): ?> selected='selected' <?php endif; ?>  ><?php echo e($data->str_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('str_id')): ?>
                            <span id="str_id-error" class="error text-danger" for="str_id"><?php echo e($errors->first('str_id')); ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Degree Medium')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('deg_medium') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="deg_medium" id="deg_medium">
                            <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                            <option value="Sinhala" <?php echo e($student->deg_medium == 'Sinhala' ? 'selected' : ''); ?>>Sinhala</option>
                            <option value="Tamil" <?php echo e($student->deg_medium == 'Tamil' ? 'selected' : ''); ?>>Tamil</option>
                            <option value="English" <?php echo e($student->deg_medium == 'English' ? 'selected' : ''); ?>>English</option>
                        </select>
                        <?php if($errors->has('deg_medium')): ?>
                            <span id="deg_medium-error" class="error text-danger" for="deg_medium"><?php echo e($errors->first('deg_medium')); ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Degree Type')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('deg_type') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="deg_type" id="deg_type">
                            <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                            <option value="General" <?php echo e($student->deg_type == 'General' ? 'selected' : ''); ?>>General</option>
                            <option value="Special" <?php echo e($student->deg_type == 'Special' ? 'selected' : ''); ?>>Special</option>
                        </select>
                        <?php if($errors->has('sex')): ?>
                            <span id="deg_type-error" class="error text-danger" for="deg_type"><?php echo e($errors->first('deg_type')); ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                    <label class="col-sm-1 col-form-label text-dark bg-info"><?php echo e(__('Degree Class')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('deg_class') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="deg_class" id="deg_class">
                            <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                            <option value="First" <?php echo e($student->deg_class == 'First' ? 'selected' : ''); ?>>First</option>
                            <option value="Second Upper" <?php echo e($student->deg_class == 'Second Upper' ? 'selected' : ''); ?>>Second Upper</option>
                            <option value="Second Lower" <?php echo e($student->deg_class == 'Second Lower' ? 'selected' : ''); ?>>Second Lower</option>
                            <option value="General" <?php echo e($student->deg_class == 'General' ? 'selected' : ''); ?>>General</option>
                        </select>
                        <?php if($errors->has('deg_class')): ?>
                            <span id="deg_class-error" class="error text-danger" for="deg_class"><?php echo e($errors->first('deg_class')); ?></span>
                        <?php endif; ?>
                        </div>
                    </div>


                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label text-dark bg-info"><?php echo e(__('Effective Date')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('deg_effective_date') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('deg_effective_date') ? ' is-invalid' : ''); ?>" name="deg_effective_date" id="deg_effective_date" type="date" placeholder="" value="<?php echo e($student->deg_effective_date); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('deg_effective_date')): ?>
                            <span id="deg_effective_date-error" class="error text-danger" for="deg_effective_date"><?php echo e($errors->first('deg_effective_date')); ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                    <label class="col-sm-2 col-form-label text-dark bg-info"><?php echo e(__('Job Preferance')); ?></label>
                    <div class="col-sm-2">
                        <div class="form-group<?php echo e($errors->has('deg_job_preference') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="deg_job_preference" id="deg_job_preference">
                            <option value="0" selected="selected" disabled="disabled">Pick one...</option>
                            <option value="Goverment" <?php echo e($student->deg_job_preference == 'Goverment' ? 'selected' : ''); ?>>Goverment</option>
                            <option value="Private" <?php echo e($student->deg_job_preference == 'Private' ? 'selected' : ''); ?>>Private</option>
                            <option value="Self Industry" <?php echo e($student->deg_job_preference == 'Self Industry' ? 'selected' : ''); ?>>Self Industry</option>
                        </select>
                        <?php if($errors->has('deg_job_preference')): ?>
                            <span id="deg_job_preference-error" class="error text-danger" for="deg_job_preference"><?php echo e($errors->first('deg_job_preference')); ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
              </div>
              <div class="card-footer ">
                <div class="col-md-6 " align="right">
                <button type="submit" class="btn btn-success"><?php echo e(__('Update')); ?></button>
                </div>
                <div class="col-md-6 " align="right">
                  <a href="<?php echo e(url('/register/graduate/show')); ?>" class="btn btn-info">
                    <span class="material-icons left">list</span>
                    Graduate Student List
                  </a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'degree_list', 'titlePage' => __('Graduated')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/pages/degree/edit.blade.php ENDPATH**/ ?>