

<?php $__env->startSection('content'); ?>
<style>
  
  hr{
    margin: 5px !important;
    border-top: 2px solid black !important;
  }
  .middle-button{
    padding: 5px;
    margin-right:10px;
    margin-top:10px;
    border-style: solid;
    border-radius:5px;
    cursor:pointer;
  }
</style>
  <div class="content">
    <div class="container-fluid">
      <div class="row " >
           <!-- <div class="col-md-12 " align="right">
             
              <a href="<?php echo e(url('/institutes')); ?>" class="btn btn-primary">
              
                <span class="material-icons left">
                list
                </span>
                Show Institute List
                </a>

            </div>-->
      </div>
      <div class="row">
        <div class="col-md-12">
          

            <div class="card ">
              <div class="card-header card-header-primary" style="padding-top:5px !important; padding-bottom:5px !important;">
                <h4 class="card-title"><?php echo e(__('Graduate Student Contact')); ?> </h4>
                
              </div>
              <div class="card-body ">
              <form method="" action="" autocomplete="off" class="form-horizontal" id="contact_form" name="contact_form">
              <!--action="<?php echo e(url('institutes')); ?>"-->
              <?php echo csrf_field(); ?>

                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Contact Type')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="contact_type" id="contact_type" required>
                            <option value="1">Email</option>
                            <option value="2">Telephone</option>
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('District')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="ds_id" id="ds_id">
                            <option value="0" selected="selected">Pick One...</option>
                            <option value="1">Kegalle</option>
                            <option value="2">Ratnapura</option>
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('DS Area')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="dv_id" id="dv_id">
                            <option value="0" selected="selected">Pick One...</option>
                            
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Gender')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="sex" id="sex">
                            <option value="0" selected="selected">Pick One...</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Stream')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="str_id" id="str_id">
                            <option value="0" selected="selected">Pick One...</option>
                            <?php $__currentLoopData = $streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($data->str_id); ?>"><?php echo e($data->str_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Degree Medium')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="deg_medium" id="deg_medium">
                            <option value="0" selected="selected">Pick One...</option>
                            <option value="Sinhala">Sinhala</option>
                            <option value="Tamil">Tamil</option>
                            <option value="English">English</option>
                        </select>
                  </div>
                </div>
                </div>
                <div class="row">
                <div class="col-sm-4">
                    <label class="col-form-label text-dark"><?php echo e(__('Institute')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="ins_id" id="ins_id">
                            <option value="0" selected="selected">Pick One...</option>
                            <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->ins_id); ?>"><?php echo e($data->ins_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Degree Type')); ?></label>
                    <div class="form-group">
                      <select class="form-control" name="deg_type" id="deg_type">
                            <option value="0" selected="selected">Pick one...</option>
                            <option value="General">General</option>
                            <option value="Special">Special</option>
                        </select>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Degree Class')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="deg_class" id="deg_class">
                            <option value="0" selected="selected">Pick one...</option>
                            <option value="First">First</option>
                            <option value="Second Upper">Second Upper</option>
                            <option value="Second Lower">Second Lower</option>
                            <option value="General">General</option>
                        </select>
                    </div>
                  </div>

                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Effective Date (From)')); ?></label>
                      <div class="form-group">
                        <input class="form-control" name="deg_effective_date_from" id="deg_effective_date_from" type="date" value="" aria-required="true"/>
                      </div>
                  </div>

                  <div class="col-sm-2">
                    <label class="col-form-label text-dark"><?php echo e(__('Effective Date (To)')); ?></label>
                      <div class="form-group">
                        <input class="form-control" name="deg_effective_date_to" id="deg_effective_date_to" type="date" value="" aria-required="true"/>
                      </div>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-4">
                    <button type="reset" id="" style="width:130px;" class="btn btn-danger"><?php echo e(__('Reset')); ?></button>
                    <button type="button" id="" style="width:130px;" onclick="contact_filter_graduate();" class="btn btn-info"><?php echo e(__('Load Data')); ?></button>
                  </div>
                </div>
                </form>
                <hr>
                <form>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">  
                      <textarea id="copy_text" name="copy_text" rows="8" cols="120"></textarea>
                    </div>
                  </div>
                  
                </div>
                </form>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="button" id="copy" class="btn btn-success"><?php echo e(__('Copy Text')); ?></button>
                <button type="button" id="clear" class="btn btn-warning"><?php echo e(__('Clear Text')); ?></button>
              </div>
            </div>
          
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'cont_degree', 'titlePage' => __('Graduate Contacts')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/pages/contact/degree.blade.php ENDPATH**/ ?>