

<?php $__env->startSection('content'); ?>
<style>
  .col-form-label{
    font-weight: bold;
    background-color: black !important;
    color: white !important;
  }
  hr{
    margin: 5px !important;
    border-top: 2px solid black !important;
  }
  .middle-button{
    padding: 5px;
    margin-right:10px;
    margin-top:10px;
    border-style: solid;
    border-radius:5px;
    cursor:pointer;
  }
</style>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" enctype="multipart/form-data" action="<?php echo e(url('import/graduate/store')); ?>" autocomplete="off" class="form-horizontal">
          <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary" style="padding-top:5px !important; padding-bottom:5px !important;">
                <h4 class="card-title"><?php echo e(__('Import Graduate Record')); ?> </h4>
                <p></p>
              </div>
              <div class="card-body ">

                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                    <?php endif; ?>
                    <div class="row">
                        <label class="col-sm-4 "><?php echo e(__('Graduate Records CSV File')); ?></label>
                        <div class="col-sm-4">
                            
                                <input type="file" accept=".csv" class="form-control form-control-lg" id="import_graduate" name="import_graduate">
                            
                        </div>
                    </div>
                </div>
            
                <div class="card-footer ml-auto mr-auto">
                    <button type="submit" class="btn btn-success"><?php echo e(__('Save')); ?></button>
                    <button type="reset" class="btn btn-primary"><?php echo e(__('Reset')); ?></button>
                </div>
            </div>
          </form>
          <br/><br/>
          <form method="post" enctype="multipart/form-data" action="<?php echo e(url('import/graduate/store')); ?>" autocomplete="off" class="form-horizontal">
          <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary" style="padding-top:5px !important; padding-bottom:5px !important;">
                <h4 class="card-title"><?php echo e(__('Import Diploma Holder Record')); ?> </h4>
                <p></p>
              </div>
              <div class="card-body ">

                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                    <?php endif; ?>
                    <div class="row">
                        <label class="col-sm-4 "><?php echo e(__('Graduate Records CSV File')); ?></label>
                        <div class="col-sm-4">
                            
                                <input type="file" accept=".csv" class="form-control form-control-lg" id="import_graduate" name="import_graduate">
                            
                        </div>
                    </div>
                </div>
            
                <div class="card-footer ml-auto mr-auto">
                    <button type="submit" class="btn btn-success"><?php echo e(__('Save')); ?></button>
                    <button type="reset" class="btn btn-primary"><?php echo e(__('Reset')); ?></button>
                </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'import_records', 'titlePage' => __('Import Record')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/pages/import/degree.blade.php ENDPATH**/ ?>