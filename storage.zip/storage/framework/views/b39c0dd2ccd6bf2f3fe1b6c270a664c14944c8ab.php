<div class="sidebar" data-color="azure" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-3.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
      <?php echo e(__('GDS Analysis')); ?>

    </a>
  </div>

  <div class="sidebar-wrapper">
    <ul class="nav">
      

      <?php if(Auth::user()->hasRole('viewer')): ?>
      <li class="nav-item<?php echo e($activePage == 'degree_list' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('register/graduate/show')); ?>">
          <i class="material-icons" style="color: blue;">school</i>
          <p><?php echo e(__('Graduate')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'diploma_list' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('register/diploma/show')); ?>">
          <i class="material-icons" style="color: blue;">receipt_long</i>
          <p><?php echo e(__('Diploma')); ?></p>
        </a>
      </li>
      <?php endif; ?>


      <?php if(!(Auth::user()->hasRole('viewer'))): ?>
      <li class="nav-item<?php echo e($activePage == 'institutes' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('institutes')); ?>">
          <i class="material-icons" style="color: blue;">business</i>
          <p><?php echo e(__('Institutes')); ?></p>
        </a>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?> ">
        <a class="nav-link " data-toggle="collapse" href="#graduate" aria-expanded="true">
          <i class="material-icons" style="color: red;">school</i>
          <p><?php echo e(__('Graduate')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="graduate">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'degree_add' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('register/graduate/create')); ?>">
                <i class="material-icons">person_add_alt</i>
                <p><?php echo e(__('Add New Graduate')); ?></p>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'degree_list' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('register/graduate/show')); ?>">
                <i class="material-icons">list</i>
                <p><?php echo e(__('Show Graduate List ')); ?></p>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?> ">
        <a class="nav-link " data-toggle="collapse" href="#diploma" aria-expanded="true">
          <i class="material-icons" style="color: green;">receipt_long</i>
          <p><?php echo e(__('Diploma')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="diploma">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'diploma_add' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('register/diploma/create')); ?>">
                <i class="material-icons">person_add_alt</i>
                <p><?php echo e(__('Add New Diploma')); ?></p>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'diploma_list' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('register/diploma/show')); ?>">
                <i class="material-icons">list</i>
                <p><?php echo e(__('Show Diploma List')); ?></p>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item<?php echo e($activePage == 'import_records' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('import')); ?>">
          <i class="material-icons" style="color: blue;">upload_file</i>
          <p><?php echo e(__('Data Import')); ?></p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('owner')): ?>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?> ">
        <a class="nav-link " data-toggle="collapse" href="#contacts" aria-expanded="true">
          <i class="material-icons" style="color: green;">import_contacts</i>
          <p><?php echo e(__('Filter Contacts')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="contacts">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'cont_degree' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('contacts/graduate/')); ?>">
                <i class="material-icons">school</i>
                <p><?php echo e(__('Graduate')); ?></p>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'cont_diploma' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('contacts/diploma/')); ?>">
                <i class="material-icons">receipt_long</i>
                <p><?php echo e(__('Diploma')); ?></p>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?> ">
        <a class="nav-link " data-toggle="collapse" href="#student_list" aria-expanded="true">
          <i class="material-icons" style="color: green;">format_list_bulleted</i>
          <p><?php echo e(__('Student List')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse" id="student_list">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'list_degree' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('list/graduate/')); ?>">
                <i class="material-icons">school</i>
                <p><?php echo e(__('Graduate')); ?></p>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'list_diploma' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('list/diploma/')); ?>">
                <i class="material-icons">receipt_long</i>
                <p><?php echo e(__('Diploma')); ?></p>
              </a>
            </li>
          </ul>
        </div>
      </li>
      
      <li class="nav-item<?php echo e($activePage == 'reports' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('report')); ?>">
          <i class="material-icons" style="color: red;">picture_as_pdf</i>
          <p><?php echo e(__('Reports')); ?></p>
        </a>
      </li>
      <?php endif; ?>

    </ul>
  </div>
</div><?php /**PATH D:\Projects\GDS Analysis\GDS_Analysis\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>