<footer class="footer">
    <div class="container">
        <nav class="float-left">
        
            Copyright &copy;
            <a href="https://planning.sg.gov.lk" target="_blank">DCS (Planning) Office, Sabaragamuwa </a>
            <script>
                document.write(new Date().getFullYear())
            </script>
            
        </nav>
        <div class="copyright float-right">
        Design & Develop by Pushpamal Gunasena (IT Assistant) 
        </div>
    </div>
</footer>